# -*- coding: utf-8 -*-
"""
Created on Wed Aug  5 09:38:02 2020

@author: Keith
"""

import matplotlib.pyplot as plt
plt.rcParams['svg.fonttype'] = 'none'
import warnings, sys, os, yaml
# warnings.filterwarnings("ignore",category=matplotlib.cbook.mplDeprecation)
# os.chdir('C:/Users/Lou/Documents/repos/LNT')
warnings.filterwarnings("ignore")
import seaborn as sns
import numpy as np
import scipy as sp
import scipy.io as sio
import scipy.stats as stats

# with open('.' + os.sep + 'loc_settings.yaml', 'r') as f:
#     loc_info = yaml.load(f)

# sys.path.append(loc_info['base_dir'] + '/Analysis')

sns.set_style('white')
plt.ioff()
fformat = 'png'
    
def createCOEFsummaryGraph(MOUSE,session):
    # MOUSE = 'LF191022_1'
    # session = '20191115'
    
    ccc = []
    for i in range(36):
        ccc = ccc + ['r',]
    for i in range(16):
        ccc = ccc + ['b',]
        
    use_data = 'summaryFile'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + session + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    coefData = loaded_data['aveCoefAll'][:,0]
    
    for i in range(len(coefData)):
        if coefData[i] < 0:
            coefData[i] = 0
        
    reg = 0
    total = 0
    for i in range(len(coefData)):
        if coefData[i] >= 0:
            if i < 36:
                reg += coefData[i]
            total += coefData[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
    ax1.set_title('Histogram of '+MOUSE+' from Reg Session: '+session)
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['r','b'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\'+MOUSE+'_'+session+'_summary.png')
    return coefData
    
    
def createMatchedCOEFgraph(MOUSE):
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
        
    use_data = 'summaryMatchFile'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    coefDataNaive = loaded_data['aveCoefAllNaive'][:,0]
    coefDataExpert = loaded_data['aveCoefAllExpert'][:,0]
    plt.clf()
    fig, (ax1, ax2) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefDataNaive,width=.95,color=ccc)
    ax1.set_title('Histogram of '+MOUSE+' Coefficients from Naive CellReg')
    ax1.set_xticklabels([])
    ax2.bar(np.arange(52),coefDataExpert,width=.95,color=ccc)
    ax2.set_title('Histogram of '+MOUSE+' Coefficients from Expert CellReg')
    ax2.set_xticklabels([])
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\'+use_data+'.png')
    
    # total = 0
    # world = 0
    # selfr = 0
    # for i in range(36):
    #     if coefData[i] >= 0:
    #         total += coefData[i]
    #         world += coefData[i]
    # for i in range(16):
    #     ind = i + 36
    #     if coefData[ind] >= 0:
    #         total += coefData[ind]
    #         selfr += coefData[ind]
            
    # plt.clf()
    # fig, ax = plt.subplots()
    # ax.bar(np.arange(2),[world/total,selfr/total],width=.95,color=['r','b'])
    # ax.set_title('Percentages of Coefficients')
    # fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\'+MOUSE+'_'+session+'_coef_perct'+add_on+'.png')
    
    
def createCorrelationsPopulation():
    allocentricPerct = []
    allo_naive = []
    allo_expert = []
    t_scores = []
    t_naive = []
    t_expert = []
    mice = ['LF191022_1','LF191022_2','LF191022_3','LF191023_blank','LF191023_blue','LF191024_1']
    
    for m in mice:
        use_data = m + 'summaryMatchFile'
        processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + m + os.sep + use_data + '.mat'
        loaded_data = sio.loadmat(processed_data_path)
        
        t_scores.append(loaded_data['naive_score'])
        t_naive.append(loaded_data['naive_score'])
        coefDataNaive = loaded_data['popaveCoefAllNaive'][:,0]
        naive = 0
        total = 0
        for i in range(len(coefDataNaive)):
            if coefDataNaive[i] >= 0:
                if i < 36:
                    naive += coefDataNaive[i]
                total += coefDataNaive[i]
        allocentricPerct.append(float(naive/total))
        allo_naive.append(float(naive/total))
        
        t_scores.append(loaded_data['expert_score'])
        t_expert.append(loaded_data['expert_score'])
        coefDataExpert = loaded_data['popaveCoefAllExpert'][:,0]
        expert = 0
        total = 0
        for i in range(len(coefDataExpert)):
            if coefDataExpert[i] >= 0:
                if i < 36:
                    expert += coefDataExpert[i]
                total += coefDataExpert[i]
        allocentricPerct.append(float(expert/total))
        allo_expert.append(float(expert/total))
        
    plt.clf()
    fig, ax = plt.subplots()
    colors = ['red','blue','green','black','orange','purple']
    ax.scatter(t_naive, allo_naive, marker='+', c=colors, s=100)
    ax.scatter(t_expert, allo_expert, marker='o', c=colors, s=100)
    correlation_pearson = stats.spearmanr(np.array(allocentricPerct, dtype='float'), np.squeeze(np.array(t_scores, dtype='float')))
    ax.set_title('t_scorese versus percentage of allocentric coding for populations')
    ax.set_xlabel('Percentage of Allocentric Encoding')
    ax.set_ylabel('t_scores of performance')
    print(correlation_pearson)
    ax.text(-30,.9,'spearman correlation: '+str(round(correlation_pearson[0], 5)))
    ax.text(-30,.8,'p-value: '+str(round(correlation_pearson[1], 5)))
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\correlation_of_performance_coding_population.png')
    ret_dict = {'pop_t_scores': np.squeeze(np.array(t_scores, dtype='float')), 'pop_allocentric': np.array(allocentricPerct, dtype='float')}
    return ret_dict
        
    
def createCorrelationsMatched():
    allocentricPerct = []
    allo_naive = []
    allo_expert = []
    t_scores = []
    t_naive = []
    t_expert = []
    mice = ['LF191022_1','LF191022_2','LF191022_3','LF191023_blank','LF191023_blue','LF191024_1']
    
    for m in mice:
        use_data = m + 'summaryMatchFile'
        processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + m + os.sep + use_data + '.mat'
        loaded_data = sio.loadmat(processed_data_path)
        
        t_scores.append(loaded_data['naive_score'])
        t_naive.append(loaded_data['naive_score'])
        coefDataNaive = loaded_data['aveCoefAllNaive'][:,0]
        naive = 0
        total = 0
        for i in range(len(coefDataNaive)):
            if coefDataNaive[i] >= 0:
                if i < 36:
                    naive += coefDataNaive[i]
                total += coefDataNaive[i]
        allocentricPerct.append(float(naive/total))
        allo_naive.append(float(naive/total))
        
        t_scores.append(loaded_data['expert_score'])
        t_expert.append(loaded_data['expert_score'])
        coefDataExpert = loaded_data['aveCoefAllExpert'][:,0]
        expert = 0
        total = 0
        for i in range(len(coefDataExpert)):
            if coefDataExpert[i] >= 0:
                if i < 36:
                    expert += coefDataExpert[i]
                total += coefDataExpert[i]
        allocentricPerct.append(float(expert/total))
        allo_expert.append(float(expert/total))
        
    plt.clf()
    fig, ax = plt.subplots()
    colors = ['red','blue','green','black','orange','purple']
    ax.scatter(t_naive, allo_naive, marker='+', c=colors, s=100)
    ax.scatter(t_expert, allo_expert, marker='o', c=colors, s=100)
    correlation_pearson = stats.spearmanr(np.array(allocentricPerct, dtype='float'), np.squeeze(np.array(t_scores, dtype='float')))
    ax.set_title('t_scorese versus percentage of allocentric coding for matched cells')
    ax.set_xlabel('Percentage of Allocentric Encoding')
    ax.set_ylabel('t_scores of performance')
    print(correlation_pearson)
    ax.text(-30,.9,'spearman correlation: '+str(round(correlation_pearson[0], 5)))
    ax.text(-30,.8,'p-value: '+str(round(correlation_pearson[1], 5)))
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\correlation_of_performance_coding_matched.png')
    ret_dict = {'match_t_scores': np.squeeze(np.array(t_scores, dtype='float')), 'match_allocentric': np.array(allocentricPerct, dtype='float')}
    return ret_dict
    

def createMatchedCOEFgraphOL(MOUSE, session):
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
        
    session_ol = session+'_ol'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + session_ol + os.sep + 'summaryMatchFile.mat'
    loaded_data = sio.loadmat(processed_data_path)
    coefDataReg = loaded_data['aveCoefAllReg'][:,0]
    coefDataOL = loaded_data['aveCoefAllOL'][:,0]
    for i in range(len(coefDataOL)):
        if coefDataReg[i] < 0:
            coefDataReg[i] = 0
        if coefDataOL[i] < 0:
            coefDataOL[i] = 0
    
    reg = 0
    total = 0
    for i in range(len(coefDataReg)):
        if coefDataReg[i] >= 0:
            if i < 36:
                reg += coefDataReg[i]
            total += coefDataReg[i]
    reg_allo = float(reg/total)
    
    ol = 0
    total = 0
    for i in range(len(coefDataOL)):
        if coefDataOL[i] >= 0:
            if i < 36:
                ol += coefDataOL[i]
            total += coefDataOL[i]
    ol_allo = float(ol/total)
    
    plt.clf()
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
    ax1.bar(np.arange(52),coefDataReg,width=.95,color=ccc)
    ax1.set_title('Histogram of '+MOUSE+' from Reg Session: '+session)
    ax1.set_xticklabels([])
    ax1.set_ylim([None,max([max(coefDataReg),max(coefDataOL)])])
    ax3.bar(np.arange(2),[reg_allo,1-reg_allo],width=.95,color=['r','b'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Reg')
    ax2.bar(np.arange(52),coefDataOL,width=.95,color=ccc)
    ax2.set_title('Histogram of OL')
    ax2.set_xticklabels([])
    ax2.set_ylim([None,max([max(coefDataReg),max(coefDataOL)])])
    ax4.bar(np.arange(2),[ol_allo,1-ol_allo],width=.95,color=['r','b'])
    ax4.set_xticklabels([])
    ax4.set_title('Ratio of OL')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\'+MOUSE+'_'+session+'_matchOL.png')
    return coefDataReg, coefDataOL


def run_ol_summary():
    naive = [('LF191022_1','20191115'),('LF191022_3','20191113'),('LF191023_blue','20191119'),('LF191022_2','20191116'),('LF191023_blank','20191114'),('LF191024_1','20191114')]
    expert = [('LF191022_1','20191209'),('LF191022_3','20191207'),('LF191023_blue','20191208'),('LF191022_2','20191210'),('LF191023_blank','20191210'),('LF191024_1','20191210')]

    ccc = []
    for i in range(36):
        ccc = ccc + ['r',]
    for i in range(16):
        ccc = ccc + ['b',]

    naive_reg = np.zeros((6,52))
    naive_ol = np.zeros((6,52))
    for i in range(len(naive)):
       curr_reg, curr_ol = createMatchedCOEFgraphOL(naive[i][0],naive[i][1])
       naive_reg[i,:] = curr_reg
       naive_ol[i,:] = curr_ol
    naive_regA = np.mean(naive_reg, axis=0)
    naive_olA = np.mean(naive_ol, axis=0)
    
    reg = 0
    total = 0
    for i in range(len(naive_regA)):
        if naive_regA[i] >= 0:
            if i < 36:
                reg += naive_regA[i]
            total += naive_regA[i]
    reg_allo_naive = float(reg/total)
    
    ol = 0
    total = 0
    for i in range(len(naive_olA)):
        if naive_olA[i] >= 0:
            if i < 36:
                ol += naive_olA[i]
            total += naive_olA[i]
    ol_allo_naive = float(ol/total)
    
    expert_reg = np.zeros((6,52))
    expert_ol = np.zeros((6,52))
    for i in range(len(naive)):
       curr_reg, curr_ol = createMatchedCOEFgraphOL(expert[i][0],expert[i][1])
       expert_reg[i,:] = curr_reg
       expert_ol[i,:] = curr_ol
    expert_regA = np.mean(expert_reg, axis=0)
    expert_olA = np.mean(expert_ol, axis=0)
    
    reg = 0
    total = 0
    for i in range(len(expert_regA)):
        if expert_regA[i] >= 0:
            if i < 36:
                reg += expert_regA[i]
            total += expert_regA[i]
    reg_allo_expert = float(reg/total)
    
    ol = 0
    total = 0
    for i in range(len(expert_olA)):
        if expert_olA[i] >= 0:
            if i < 36:
                ol += expert_olA[i]
            total += expert_olA[i]
    ol_allo_expert = float(ol/total)

    plt.clf()
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
    ax1.bar(np.arange(52),naive_regA,width=.95,color=ccc)
    ax1.set_title('Histogram of all naive mice (REG)')
    ax1.set_xticklabels([])
    ax1.set_ylim([None,max([max(naive_regA),max(naive_olA)])])
    ax3.bar(np.arange(2),[reg_allo_naive,1-reg_allo_naive],width=.95,color=['r','b'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Reg')
    ax2.bar(np.arange(52),naive_olA,width=.95,color=ccc)
    ax2.set_title('Histogram of OL')
    ax2.set_xticklabels([])
    ax2.set_ylim([None,max([max(naive_regA),max(naive_olA)])])
    ax4.bar(np.arange(2),[ol_allo_naive,1-ol_allo_naive],width=.95,color=['r','b'])
    ax4.set_xticklabels([])
    ax4.set_title('Ratio of OL')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\summary_naive_matchOL.png')
    
    plt.clf()
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
    ax1.bar(np.arange(52),expert_regA,width=.95,color=ccc)
    ax1.set_title('Histogram of all expert mice (REG)')
    ax1.set_xticklabels([])
    ax1.set_ylim([None,max([max(expert_regA),max(expert_olA)])])
    ax3.bar(np.arange(2),[reg_allo_expert,1-reg_allo_expert],width=.95,color=['r','b'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Reg')
    ax2.bar(np.arange(52),expert_olA,width=.95,color=ccc)
    ax2.set_title('Histogram of OL')
    ax2.set_xticklabels([])
    ax2.set_ylim([None,max([max(expert_regA),max(expert_olA)])])
    ax4.bar(np.arange(2),[ol_allo_expert,1-ol_allo_expert],width=.95,color=['r','b'])
    ax4.set_xticklabels([])
    ax4.set_title('Ratio of OL')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\summary_expert_matchOL.png')

        
def run_layer5_summary():
    sessions = [('LF191022_1','20191213'),('LF191022_2','20191212'),('LF191022_3','20191211'),('LF191023_blank','20191213'),('LF191023_blue','20191212')]
    ccc = []
    for i in range(36):
        ccc = ccc + ['r',]
    for i in range(16):
        ccc = ccc + ['b',]
    
    coef_run = np.zeros((5,52))
    for i in range(len(sessions)):
        cur_coef = createCOEFsummaryGraph(sessions[i][0], sessions[i][1])
        coef_run[i,:] = cur_coef
        
    coef_ave = np.mean(coef_run,axis=0)
    reg = 0
    total = 0
    for i in range(len(coef_ave)):
        if coef_ave[i] >= 0:
            if i < 36:
                reg += coef_ave[i]
            total += coef_ave[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coef_ave,width=.95,color=ccc)
    ax1.set_title('Histogram of average layer 5 Coefficients')
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['r','b'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\average_layer_5_summary.png')
    
def createSingleSessSum(MOUSE,session):
    # MOUSE = 'LF191022_1'
    # session = '20191115'
    
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
        
    use_data = 'summaryFile'
    processed_data_path = 'D:\\Lukas\\data\\animals_raw\\' + MOUSE + os.sep + session + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    coefData = loaded_data['coefAves'].T
    
    for i in range(len(coefData[0,:])):
        for j in range(len(coefData[:,0])):
            if coefData[j,i] <= 0:
                coefData[j,i] = 0.00000000001
    
    matrix_data = np.copy(coefData)
    for i in range(len(matrix_data[:,0])):
        matrix_data[i,:] = matrix_data[i,:]/max(matrix_data[i,:])
    
    plt.clf()
    fig, axx = plt.subplots()
    sns.heatmap(matrix_data, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + ' :: ' + session)
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\heatmap_' +'_'+MOUSE+'_'+session+'.png')
    
    coefData = np.mean(coefData,axis=0)
    
    reg = 0
    total = 0
    for i in range(len(coefData)):
        if coefData[i] >= 0:
            if i < 36:
                reg += coefData[i]
            total += coefData[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
    ax1.set_ylim(top=.255)
    ax1.set_title('Histogram of '+MOUSE+' from Reg Session: '+session)
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['#EC008C','#009444'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\'+MOUSE+'_'+session+'_summary.svg')
    return coefData

def run_naive_analysis():
    
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
    
    res = []
    res.append(createSingleSessSum('LF191022_1','20191115'))
    res.append(createSingleSessSum('LF191022_2','20191116'))
    res.append(createSingleSessSum('LF191022_3','20191113'))
    res.append(createSingleSessSum('LF191023_blank','20191114'))
    res.append(createSingleSessSum('LF191023_blue','20191119'))
    res.append(createSingleSessSum('LF191024_1','20191115'))

    res = np.array(res)
    coefData = np.mean(res,axis=0)
    
    reg = 0
    total = 0
    for i in range(len(coefData)):
        if coefData[i] >= 0:
            if i < 36:
                reg += coefData[i]
            total += coefData[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
    ax1.set_title('Histogram of All Naive Mice')
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['#EC008C','#009444'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\naive_summary.svg')
    return coefData


def run_expert_analysis():
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
    
    res = []
    res.append(createSingleSessSum('LF191022_1','20191209'))
    res.append(createSingleSessSum('LF191022_2','20191210'))
    res.append(createSingleSessSum('LF191022_3','20191207'))
    res.append(createSingleSessSum('LF191023_blank','20191210'))
    res.append(createSingleSessSum('LF191023_blue','20191208'))
    res.append(createSingleSessSum('LF191024_1','20191210'))

    res = np.array(res)
    coefData = np.mean(res,axis=0)
    
    reg = 0
    total = 0
    for i in range(len(coefData)):
        if coefData[i] >= 0:
            if i < 36:
                reg += coefData[i]
            total += coefData[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
    ax1.set_title('Histogram of All Expert Mice')
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['#EC008C','#009444'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\expert_summary.svg')
    return coefData

def run_layer_2_3_analyisis():
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
    
    mice = ['LF191022_1','LF191022_2','LF191022_3','LF191023_blank','LF191023_blue','LF191024_1']
    sessions = ['20191204','20191205','20191206','20191207','20191208','20191209','20191210']
    res = []
    for m in mice:
        for s in sessions:
            try:
                res.append(createSingleSessSum(m,s))
            except:
                pass

    res = np.array(res)
    coefData = np.mean(res,axis=0)
    
    reg = 0
    total = 0
    for i in range(len(coefData)):
        if coefData[i] >= 0:
            if i < 36:
                reg += coefData[i]
            total += coefData[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
    ax1.set_title('Histogram of All Layer 2/3 Sessions')
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['#EC008C','#009444'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\layer_2_3_summary.svg')
    return coefData


def run_layer_5_analyisis():
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
    
    mice = ['LF191022_1','LF191022_2','LF191022_3','LF191023_blank','LF191023_blue','LF191024_1']
    sessions = ['20191211','20191212','20191213','20191214','20191215','20191216','20191217']
    res = []
    for m in mice:
        for s in sessions:
            try:
                res.append(createSingleSessSum(m,s))
            except:
                pass

    res = np.array(res)
    coefData = np.mean(res,axis=0)
    
    reg = 0
    total = 0
    for i in range(len(coefData)):
        if coefData[i] >= 0:
            if i < 36:
                reg += coefData[i]
            total += coefData[i]
    allo_perct = float(reg/total)
    
    plt.clf()
    fig, (ax1, ax3) = plt.subplots(2, 1)
    ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
    ax1.set_title('Histogram of All Layer 5 Sessions')
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[allo_perct,1-allo_perct],width=.95,color=['#EC008C','#009444'])
    ax3.set_xticklabels([])
    ax3.set_title('Ratio of Coefficients')
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\layer_5_summary.svg')
    return coefData

def createMatchedStats(MOUSE):
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
        
    processed_data_path = 'D:\\Lukas\\data\\animals_raw\\' + MOUSE + os.sep + 'summaryMatchFile.mat'
    loaded_data = sio.loadmat(processed_data_path)
    coefDataReg = loaded_data['coefAvesExpert'].T
    coefDataNaive = loaded_data['coefAvesNaive'].T
    
    for i in range(len(coefDataReg[0,:])):
        for j in range(len(coefDataReg[:,0])):
            if coefDataReg[j,i] <= 0:
                coefDataReg[j,i] = 0.00000000001
    coefDataReg = np.mean(coefDataReg,axis=0)
    
    for i in range(len(coefDataNaive[0,:])):
        for j in range(len(coefDataNaive[:,0])):
            if coefDataNaive[j,i] <= 0:
                coefDataNaive[j,i] = 0.00000000001
    coefDataNaive = np.mean(coefDataNaive,axis=0)
    
    reg = 0
    total = 0
    for i in range(len(coefDataReg)):
        if coefDataReg[i] >= 0:
            if i < 36:
                reg += coefDataReg[i]
            total += coefDataReg[i]
    reg_allo = float(reg/total)
    
    naive = 0
    total = 0
    for i in range(len(coefDataNaive)):
        if coefDataNaive[i] >= 0:
            if i < 36:
                naive += coefDataNaive[i]
            total += coefDataNaive[i]
    naive_allo = float(naive/total)
    
    plt.clf()
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2)
    ax1.bar(np.arange(52),coefDataNaive,width=.95,color=ccc)
    ax1.set_ylim(top=.255)
    ax1.set_title('Histogram of '+MOUSE+' from Naive Session')
    ax1.set_xticklabels([])
    ax3.bar(np.arange(2),[naive_allo,1-naive_allo],width=.95,color=['#EC008C','#009444'])
    ax3.set_xticklabels([])
    ax3.set_ylim(top=.77)
    ax3.set_title('Ratio of Naive')
    ax2.bar(np.arange(52),coefDataReg,width=.95,color=ccc)
    ax2.set_ylim(top=.255)
    ax2.set_title('Histogram of Expert Session')
    ax2.set_xticklabels([])
    ax4.bar(np.arange(2),[reg_allo,1-reg_allo],width=.95,color=['#EC008C','#009444'])
    ax4.set_xticklabels([])
    ax4.set_ylim(top=.77)
    ax4.set_title('Ratio of Expert')
    fig.savefig(r'C:\Users\Lou\Documents\check-up\\'+MOUSE+'_match_expert_session.svg')
    return coefDataReg, coefDataNaive

def run_ind_layer_5():
    ccc = []
    for i in range(36):
        ccc = ccc + ['#EC008C',]
    for i in range(16):
        ccc = ccc + ['#009444',]
    
    MOUSE = 'LF191022_2'
    sessions = ['20191206','20191208','20191210']
    rois = [31,48,23]
    
    for c,s in enumerate(sessions):
        use_data = 'glm_data.mat'
        processed_data_path = 'D:\\Lukas\\dataset\\' + MOUSE + '_' + s + '_' + use_data
        loaded_data = sio.loadmat(processed_data_path)
        coefData = loaded_data['data'].T
        
        for i in range(len(coefData[0,:])):
            for j in range(len(coefData[:,0])):
                if coefData[j,i] <= 0:
                    coefData[j,i] = 0.00000000001
        coefData = coefData[rois[c],1:]
        plt.clf()
        fig, (ax1) = plt.subplots(1, 1)
        ax1.bar(np.arange(52),coefData,width=.95,color=ccc)
        ax1.set_ylim(top=3)
        ax1.set_title('Histogram of ROI '+str(rois[c])+' from '+MOUSE+'---'+s)
        ax1.set_xticklabels([])
        fig.savefig(r'C:\Users\Lou\Documents\check-up\\'+ MOUSE + '_' + s + '_' + str(rois[c]) + '.svg')
        
    
if __name__ == '__main__':

#     createSingleSessSum('LF191022_1','20191115')
#     createSingleSessSum('LF191022_1','20191209')
    # createCOEFsummaryGraph('LF191022_3','20191113')
    # createCOEFsummaryGraph('LF191022_3','20191207')
    # createCOEFsummaryGraph('LF191023_blue','20191119')
    # createCOEFsummaryGraph('LF191023_blue','20191208')
    # createCOEFsummaryGraph('LF191022_2','20191116')
    # createCOEFsummaryGraph('LF191022_2','20191210')
    # createCOEFsummaryGraph('LF191023_blank','20191114')
    # createCOEFsummaryGraph('LF191023_blank','20191210')
    # createCOEFsummaryGraph('LF191024_1','20191115')
    # createCOEFsummaryGraph('LF191024_1','20191210')
#    run_layer_2_3_analyisis()
#    run_layer_5_analyisis()
#    run_naive_analysis()
#    run_expert_analysis()
    # createMatchedCOEFgraph('LF191022_1')
    # createMatchedCOEFgraph('LF191022_2')
    # createMatchedCOEFgraph('LF191022_3')
    # createMatchedCOEFgraph('LF191023_blank')
    # createMatchedCOEFgraph('LF191023_blue')
    # createMatchedCOEFgraph('LF191024_1')
    
    # createMatchedCOEFgraphOL('LF191022_1','20191115')
    # createMatchedCOEFgraphOL('LF191022_1','20191209')
    # createMatchedCOEFgraphOL('LF191022_3','20191113')
    # createMatchedCOEFgraphOL('LF191022_3','20191207')
    # createMatchedCOEFgraphOL('LF191023_blue','20191119')
    # createMatchedCOEFgraphOL('LF191023_blue','20191208')
    # createMatchedCOEFgraphOL('LF191022_2','20191116')
    # createMatchedCOEFgraphOL('LF191022_2','20191210')
    # createMatchedCOEFgraphOL('LF191023_blank','20191114')
    # createMatchedCOEFgraphOL('LF191023_blank','20191210')
    # createMatchedCOEFgraphOL('LF191024_1','20191114')
    # createMatchedCOEFgraphOL('LF191024_1','20191210')
    
#    createMatchedStats('LF191022_1')
#    createSingleSessSum('LF191022_1','20191115')
#    createSingleSessSum('LF191022_1','20191209')
#    createSingleSessSum('LF191022_1','20191217')
    
    run_ind_layer_5()
    
    # run_ol_summary()
    
    