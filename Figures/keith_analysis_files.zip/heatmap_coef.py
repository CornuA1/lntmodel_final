# -*- coding: utf-8 -*-
"""
Created on Wed Aug  5 02:45:25 2020

@author: Lou
"""

import matplotlib.pyplot as plt
plt.rcParams['svg.fonttype'] = 'none'
import warnings, sys, os, yaml
# warnings.filterwarnings("ignore",category=matplotlib.cbook.mplDeprecation)
# os.chdir('C:/Users/Lou/Documents/repos/LNT')
warnings.filterwarnings("ignore")
import seaborn as sns
import numpy as np
import scipy as sp
import scipy.io as sio


# with open('.' + os.sep + 'loc_settings.yaml', 'r') as f:
#     loc_info = yaml.load(f)

# sys.path.append(loc_info['base_dir'] + '/Analysis')

sns.set_style('white')

fformat = 'png'


    
def run_a_lot_of_files():
    MOUSE = 'LF191022_1'
    use_data = 'LF191022_1_matched_cells_15_09_matrix'

    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)

    leng = 'coef_matrix_short'
    leg = ' Short '
    plt.clf()
    fig, axx = plt.subplots()
    place = loaded_data[leng].T
    new_place = np.concatenate((place[:,:16],place[:,18:]),axis=1)
    sns.heatmap(new_place, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + leg + 'Track Neurons from Naive Session')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'.png')
    plt.clf()
    fig, axx = plt.subplots()
    axx.bar(np.arange(26),np.sum(new_place,axis=0),width=.95,color=ccc)
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'_new_histo.png')
    
    leng = 'coef_matrix_long'
    leg = ' Long '
    plt.clf()
    fig, axx = plt.subplots()
    sns.heatmap(loaded_data[leng].T, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + leg + 'Track Neurons from Naive Session')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'.png')
    plt.clf()
    fig, axx = plt.subplots()
    axx.bar(np.arange(28),np.sum(loaded_data[leng].T,axis=0),width=.95,color=ccc)
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'_new_histo.png')
    
    leng = 'coef_matrix_short_x'
    leg = ' Short '
    plt.clf()
    fig, axx = plt.subplots()
    place = loaded_data[leng].T
    new_place = np.concatenate((place[:,:16],place[:,18:]),axis=1)
    sns.heatmap(new_place, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + leg + 'Track Neurons from Expert Session')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'.png')
    plt.clf()
    fig, axx = plt.subplots()
    axx.bar(np.arange(26),np.sum(new_place,axis=0),width=.95,color=ccc)
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'_new_histo.png')
    
    leng = 'coef_matrix_long_x'
    leg = ' Long '
    plt.clf()
    fig, axx = plt.subplots()
    sns.heatmap(loaded_data[leng].T, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + leg + 'Track Neurons from Expert Session')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'.png')
    plt.clf()
    fig, axx = plt.subplots()
    axx.bar(np.arange(28),np.sum(loaded_data[leng].T,axis=0),width=.95,color=ccc)
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'_new_histo.png')
    
    
def run_single_files():
    MOUSE = 'LF191022_1'
    use_data = 'LF191022_1_cells_12_matrix'

    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)

    leng = 'coef_matrix_short'
    leg = ' Short '
    plt.clf()
    fig, axx = plt.subplots()
    place = loaded_data[leng].T
    new_place = np.concatenate((place[:,:16],place[:,18:]),axis=1)
    ax1 = sns.heatmap(new_place, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + leg + 'Track Neurons from Naive Session')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'.png')
    
    leng = 'coef_matrix_long'
    leg = ' Long '
    plt.clf()
    fig, axx = plt.subplots()
    ax1 = sns.heatmap(loaded_data[leng].T, ax=axx)
    axx.set_xlabel('Coefficients')
    axx.set_ylabel('Neurons')
    axx.set_title('Heatmap of ' + MOUSE + leg + 'Track Neurons from Naive Session')
    fig.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\' + use_data +'_'+leng+'.png')
    
    
def run_big_boi():
    naive = 'naive_total'
    expert = 'expert_total'

    MOUSE = 'LF191022_1'
    use_data = 'LF191022_1_big_boi_15_09'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    
    naive_world_1 = np.sum(loaded_data[naive].T[:,:18])
    naive_self_1 = np.sum(loaded_data[naive].T[:,18:])
    naive_test_1 = naive_world_1 + naive_self_1
    expert_world_1 = np.sum(loaded_data[expert].T[:,:18])
    expert_self_1 = np.sum(loaded_data[expert].T[:,18:])
    expert_test_1 = expert_world_1 + expert_self_1
    
    MOUSE = 'LF191022_2'
    use_data = 'LF191022_2_big_boi_16_10'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    
    naive_world_2 = np.sum(loaded_data[naive].T[:,:18])
    naive_self_2 = np.sum(loaded_data[naive].T[:,18:])
    naive_test_2 = naive_world_2 + naive_self_2
    expert_world_2 = np.sum(loaded_data[expert].T[:,:18])
    expert_self_2 = np.sum(loaded_data[expert].T[:,18:])
    expert_test_2 = expert_world_2 + expert_self_2
    
    MOUSE = 'LF191022_3'
    use_data = 'LF191022_3_big_boi_13_07'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    
    naive_world_3 = np.sum(loaded_data[naive].T[:,:18])
    naive_self_3 = np.sum(loaded_data[naive].T[:,18:])
    naive_test_3 = naive_world_3 + naive_self_3
    expert_world_3 = np.sum(loaded_data[expert].T[:,:18])
    expert_self_3 = np.sum(loaded_data[expert].T[:,18:])
    expert_test_3 = expert_world_3 + expert_self_3
    
    MOUSE = 'LF191023_blank'
    use_data = 'LF191023_blank_big_boi_14_10'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    
    naive_world_blank = np.sum(loaded_data[naive].T[:,:18])
    naive_self_blank = np.sum(loaded_data[naive].T[:,18:])
    naive_test_blank = naive_world_blank + naive_self_blank
    expert_world_blank = np.sum(loaded_data[expert].T[:,:18])
    expert_self_blank = np.sum(loaded_data[expert].T[:,18:])
    expert_test_blank = expert_world_blank + expert_self_blank
    
    MOUSE = 'LF191023_blue'
    use_data = 'LF191023_blue_big_boi_19_08'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    
    naive_world_blue = np.sum(loaded_data[naive].T[:,:18])
    naive_self_blue = np.sum(loaded_data[naive].T[:,18:])
    naive_test_blue = naive_world_blue + naive_self_blue
    expert_world_blue = np.sum(loaded_data[expert].T[:,:18])
    expert_self_blue = np.sum(loaded_data[expert].T[:,18:])
    expert_test_blue = expert_world_blue + expert_self_blue
    
    MOUSE = 'LF191024_1'
    use_data = 'LF191024_1_big_boi_14_10'
    processed_data_path = 'Q:\\Documents\\Harnett UROP\\' + MOUSE + os.sep + use_data + '.mat'
    loaded_data = sio.loadmat(processed_data_path)
    
    naive_world_24 = np.sum(loaded_data[naive].T[:,:18])
    naive_self_24 = np.sum(loaded_data[naive].T[:,18:])
    naive_test_24 = naive_world_24 + naive_self_24
    expert_world_24 = np.sum(loaded_data[expert].T[:,:18])
    expert_self_24 = np.sum(loaded_data[expert].T[:,18:])
    expert_test_24 = expert_world_24 + expert_world_24
    
    naive_world_sum = np.array([naive_world_1,naive_world_2,naive_world_3,naive_world_blank,naive_world_blue,naive_world_24])
    naive_world_test = np.array([naive_world_1/naive_test_1, naive_world_2/naive_test_2, naive_world_3/naive_test_3, naive_world_blank/naive_test_blank, naive_world_blue/naive_test_blue ,naive_world_24/naive_test_24])         
    naive_self_test = np.ones((6,)) - naive_world_test
    print(sp.stats.ttest_ind(naive_world_test,naive_self_test))
    nws = sp.stats.sem(naive_world_sum)
    naive_self_sum = np.array([naive_self_1,naive_self_2,naive_self_3,naive_self_blank,naive_self_blue,naive_self_24])
    nss = sp.stats.sem(naive_self_sum)
    # print(sp.stats.ttest_rel(naive_world_sum,naive_self_sum))
    expert_world_sum = np.array([expert_world_1,expert_world_2,expert_world_3,expert_world_blank,expert_world_blue,expert_world_24])
    expert_world_test = np.array([expert_world_1/expert_test_1, expert_world_2/expert_test_2, expert_world_3/expert_test_3, expert_world_blank/expert_test_blank, expert_world_blue/expert_test_blue, expert_world_24/expert_test_24])              
    expert_naive_test = np.ones((6,)) - expert_world_test
    print(sp.stats.ttest_ind(expert_world_test,expert_naive_test))
    ews = sp.stats.sem(expert_world_sum)
    expert_self_sum = np.array([expert_self_1,expert_self_2,expert_self_3,expert_self_blank,expert_self_blue,expert_self_24])
    ess = sp.stats.sem(expert_self_sum)
    # print(sp.stats.ttest_rel(expert_world_sum,expert_self_sum))
    # print(sp.stats.ttest_rel(naive_world_sum-naive_self_sum,expert_world_sum-expert_self_sum))

    
    # good_naive_world = np.array([naive_world_1,naive_world_3,naive_world_blue])
    # gnw = sp.stats.sem(good_naive_world)
    # good_naive_self = np.array([naive_self_1,naive_self_3,naive_self_blue])
    # gns = sp.stats.sem(good_naive_self)
    good_expert_world = np.array([expert_world_1,expert_world_3,expert_world_blue])
    good_expert_w_t = np.array([expert_world_1/expert_test_1, expert_world_3/expert_test_3, expert_world_blue/expert_test_blue])
    gew = sp.stats.sem(good_expert_world)
    good_expert_self = np.array([expert_self_1,expert_self_3,expert_self_blue])
    good_expert_s_t = np.ones((3,)) - good_expert_w_t
    ges = sp.stats.sem(good_expert_self)
    print(sp.stats.ttest_ind(good_expert_w_t,good_expert_s_t))
    # bad_naive_world = np.array([naive_world_2,naive_world_blank,naive_world_24])
    # bnw = sp.stats.sem(bad_naive_world)
    # bad_naive_self = np.array([naive_self_2,naive_self_blank,naive_self_24])
    # bns = sp.stats.sem(bad_naive_self)
    bad_expert_world = np.array([expert_world_2,expert_world_blank,expert_world_24])
    bad_expert_w_t = np.array([expert_world_2/expert_test_2, expert_world_blank/expert_test_blank, expert_world_24/expert_test_24])
    bew = sp.stats.sem(bad_expert_world)
    bad_expert_self = np.array([expert_self_2,expert_self_blank,expert_self_24])
    bad_expert_s_t = np.ones((3,)) - bad_expert_w_t
    bes = sp.stats.sem(bad_expert_self)
    print(sp.stats.ttest_rel(bad_expert_w_t,bad_expert_s_t))
    # print(sp.stats.ttest_ind(good_expert_world-good_expert_self,bad_expert_world-bad_expert_self))
    
    print(sp.stats.ttest_ind(good_expert_w_t-good_expert_s_t,bad_expert_w_t-bad_expert_s_t))
    
    nsum = np.sum(naive_self_sum) + np.sum(naive_world_sum)
    xsum = np.sum(expert_self_sum) + np.sum(expert_world_sum)
    gsum = np.sum(good_expert_self) + np.sum(good_expert_world)
    bsum = np.sum(bad_expert_self) + np.sum(bad_expert_world)
    
    mult_factor = 1
    
    # barWidth = 0.2
    # br1 = np.arange(3) 
    # br2 = [x + barWidth for x in br1] 
    # br3 = [x + barWidth for x in br2] 
    # br4 = [x + barWidth for x in br3] 
    # fig1, ax1 = plt.subplots()
    # ax1.bar(br1, [np.sum(naive_self_sum),np.sum(good_naive_self),np.sum(bad_naive_self)], yerr=[nss,gns,bns], color ='b', width = barWidth, edgecolor ='white', label='Naive SR') 
    # ax1.bar(br2, [np.sum(naive_world_sum),np.sum(good_naive_world),np.sum(bad_naive_world)], yerr=[nws,gnw,bnw], color ='r', width = barWidth, edgecolor ='white', label='Naive WR') 
    # ax1.bar(br3, [np.sum(expert_self_sum),np.sum(good_expert_self),np.sum(bad_expert_self)], yerr=[ess,ges,bes], color ='g', width = barWidth, edgecolor ='white', label='Expert SR') 
    # ax1.bar(br4, [np.sum(expert_world_sum),np.sum(good_expert_world),np.sum(bad_expert_world)], yerr=[ews,gew,bew], color ='c', width = barWidth, edgecolor ='white', label='Expert WR')
    # plt.xticks([r + barWidth+0.1 for r in range(3)], ['All mice', 'Best performing mice', 'Worst performing mice']) 
    if False:
        barWidth = 0.2
        br1 = np.arange(2) 
        br2 = [x + barWidth for x in br1] 
        br3 = [x + barWidth for x in br2] 
        br4 = [x + barWidth for x in br3] 
        fig1, ax1 = plt.subplots()
        ax1.bar(br1, [mult_factor*np.sum(naive_self_sum)/nsum,mult_factor*np.sum(good_expert_self)/gsum], yerr=[nss/nsum,ges/gsum], color ='g', width = barWidth, edgecolor ='white', label='Naive SR') 
        ax1.bar(br2, [mult_factor*np.sum(naive_world_sum)/nsum,mult_factor*np.sum(good_expert_world)/gsum], yerr=[nws/nsum,gew/gsum], color ='c', width = barWidth, edgecolor ='white', label='Naive WR') 
        ax1.bar(br3, [mult_factor*np.sum(expert_self_sum)/xsum,mult_factor*np.sum(bad_expert_self)/bsum], yerr=[ess/xsum,bes/bsum], color ='b', width = barWidth, edgecolor ='white', label='Expert SR') 
        ax1.bar(br4, [mult_factor*np.sum(expert_world_sum)/xsum,mult_factor*np.sum(bad_expert_world)/bsum], yerr=[ews/xsum,bew/bsum], color ='r', width = barWidth, edgecolor ='white', label='Expert WR')
        plt.xticks([r + barWidth+0.1 for r in range(2)], ['All mice', 'Best vs Worst performing mice']) 
        plt.legend()
        # plt.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\4_graph_axis.svg', format='svg')
        
        # xxxxxx = [nss/nsum+nws/nsum, ess/xsum+ews/xsum, ges/gsum+gew/gsum, bes/bsum+bew/bsum]
    # fig2, ax2 = plt.subplots()
    # ax2.pie([expert_world_sum,expert_self_sum], labels=labels, autopct='%1.1f%%', colors=['r','b'])
    # ax2.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    # plt.savefig('Q:\\Documents\\Harnett UROP\\Check-up\\expert_bad.svg', format='svg')

    

if __name__ == '__main__':
    ccc = ['r','r','r','r','r','r','r','r','r','r','r','r','r','r','r','r','r','r','b','b','b','b','b','b','b','b','b','b',]

#    leng = 'long'
#    lenlevel = ' Layer 2/3 Naive Long '
    run_big_boi()

    
    
    